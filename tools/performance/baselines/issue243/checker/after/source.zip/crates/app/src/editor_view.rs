//! Document-addressed view state. Hosts own placement; the session owns authored data.

use crate::{
    canvas_camera::{Camera, MAX_BOARD_ZOOM, MAX_ZOOM},
    schematic_canvas::{Draft, LegTarget, Tool},
};
use pcbcraft_engine::{Session, SheetTarget, board::view::BoardTarget, selection::Selection};
use std::sync::Arc;

#[cfg(test)]
mod tests;

/// Stable arrangement key for the connection overlay, separate from physical layer UUIDs.
pub(super) const RATSNEST_KEY: &str = "ratsnest";

/// Runtime view identity, independent of its document or native window.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub(super) struct ViewId(pub(super) u64);

/// Built-in document presentations, not a plugin package API. Plugin tools/providers use
/// host contracts without acquiring ownership of the documents they inspect or edit.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub(super) enum Workspace {
    #[default]
    Schematic,
    Board,
}

impl Workspace {
    /// Resolve a presentation name without using it as a persistent identity.
    pub(super) fn title(self) -> &'static str {
        match self {
            Self::Schematic => "Schematic",
            Self::Board => "PCB layout",
        }
    }

    /// Maximum manual camera zoom for this workspace.
    pub(super) fn max_zoom(self) -> f32 {
        match self {
            Self::Schematic => MAX_ZOOM,
            Self::Board => MAX_BOARD_ZOOM,
        }
    }
}

/// Captured input expires across focus, workspace, project-opening and revision changes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct ViewInput {
    view: ViewId,
    target: Option<DocumentTarget>,
    definition: Option<u64>,
    input_epoch: u64,
    pub(super) revision: u64,
}

impl ViewInput {
    /// Address the view independently of where the host currently paints it.
    pub(super) fn view(self) -> ViewId {
        self.view
    }
}

/// Document and empty-workspace targets are distinct from the local view and display name.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub(super) enum DocumentTarget {
    Sheet(SheetTarget),
    Board(BoardTarget),
    /// A PCB workspace has no physical target until a board is explicitly created.
    BoardWorkspace(uuid::Uuid),
}

impl DocumentTarget {
    /// The workspace displaying this document or the project-scoped empty board.
    fn workspace(self) -> Workspace {
        match self {
            Self::Sheet(_) => Workspace::Schematic,
            Self::Board(_) | Self::BoardWorkspace(_) => Workspace::Board,
        }
    }

    /// Resolve an addressed document or project-scoped empty workspace; names are not identities.
    pub(super) fn available(self, session: &Session) -> bool {
        session.project().is_some_and(|project| match self {
            Self::Sheet(target) => project.for_sheet(target).is_some(),
            Self::Board(target) => project.board_view(target).is_some(),
            Self::BoardWorkspace(project_id) => project.id() == project_id,
        })
    }
}

/// Serializable presentation for an explicitly addressed document, excluding edit authority.
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub(super) struct ViewState {
    target: DocumentTarget,
    title: String,
    camera: crate::canvas_camera::CameraState,
    parked_camera: crate::canvas_camera::CameraState,
    board: Option<BoardTarget>,
    #[serde(default)]
    schematic: Option<SheetTarget>,
    hidden_layers: std::collections::BTreeSet<String>,
    active_layer: Option<String>,
    layers_collapsed: bool,
    browser_collapsed: bool,
    properties_collapsed: bool,
    #[serde(default)]
    filters: crate::selection_filters::Filters,
    #[serde(default)]
    filters_collapsed: bool,
    #[serde(default = "filters_open_default")]
    filters_open: bool,
    #[serde(default = "crate::workspace_panels::saved_defaults")]
    panels: crate::workspace_panels::SavedPanels,
}

/// Existing arrangements predate the card and should show it when first upgraded.
fn filters_open_default() -> bool {
    true
}

impl ViewState {
    /// Bound layer data and validate transforms before replacing live views.
    pub(super) fn valid(&self) -> bool {
        let workspace = self.target.workspace();
        let parked = match workspace {
            Workspace::Schematic => Workspace::Board,
            Workspace::Board => Workspace::Schematic,
        };
        self.title.len() <= 1024
            && self.panels.valid()
            && self.camera.valid(workspace.max_zoom())
            && self.parked_camera.valid(parked.max_zoom())
            && self.hidden_layers.len() <= 128
            && self.hidden_layers.iter().chain(self.active_layer.iter()).all(|id| id.len() <= 128)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct Binding {
    target: DocumentTarget,
    history_root_revision: u64,
}

impl Binding {
    /// Resolve a target in the current opening, including an empty PCB workspace or a board
    /// without setup or placements. An explicit missing board never becomes the empty workspace.
    fn current(session: &Session, workspace: Workspace, board: Option<BoardTarget>, sheet: Option<SheetTarget>) -> Option<Self> {
        let project = session.project()?;
        let target = match workspace {
            Workspace::Schematic => DocumentTarget::Sheet(project.for_sheet(sheet.unwrap_or_else(|| project.sheet_target()))?.sheet_target()),
            Workspace::Board => match board {
                Some(board) => DocumentTarget::Board(project.board_view(board)?.target),
                None if project.board_target().is_none() => DocumentTarget::BoardWorkspace(project.id()),
                None => return None,
            },
        };
        Some(Self { target, history_root_revision: session.history_root_revision() })
    }
}

/// Derived copper assignments belong to one board and captured view/revision authority.
#[derive(Debug)]
pub(super) struct CopperConnectivityCache {
    source: ViewInput,
    target: BoardTarget,
    connectivity: Arc<crate::board_appearance::Connectivity>,
}

/// Schematic interaction state is separate from board selection and input handling.
#[derive(Debug, Default)]
pub(super) struct SchematicState {
    /// Derived drawing warnings follow this view's lifetime, outside project files and history.
    pub(super) overlap_cache: crate::schematic_canvas::OverlapCache,
    pub(super) clipboard: crate::clipboard::State,
    pub(super) properties: crate::properties::State,
    pub(super) selection: Selection,
    pub(super) selected_sheet_symbol: Option<u64>,
    pub(super) selected_leg: Option<LegTarget>,
    pub(super) whole_wire_drag: bool,
    pub(super) tool: Option<Tool>,
    pub(super) wire_draft: Draft,
    pub(super) rotate_requested: bool,
    /// A requested screen-axis reflection of the hovered or selected symbol.
    pub(super) mirror_requested: Option<pcbcraft_engine::schematic::MirrorAxis>,
    pub(super) edit_requested: bool,
    pub(super) text_edit: Option<crate::inline_text::Edit>,
    pub(super) datasheet_requested: bool,
    pub(super) move_requested: bool,
}

/// Board interaction state. Layer visibility and selection are local, never authored edits.
/// New views hide fabrication/courtyard layers once setup exists; restores preserve user choices.
#[derive(Debug, Default)]
pub(super) struct BoardState {
    pub(super) clipboard: crate::board_clipboard::State,
    pub(super) ratsnest_cache: Option<(ViewInput, std::sync::Arc<pcbcraft_engine::board::ratsnest::Ratsnest>)>,
    pub(super) drawing: crate::board_drawing::State,
    pub(super) tracks: crate::board_tracks::State,
    /// The last design rules check run from this view, with its card and focused finding.
    pub(super) drc: crate::board_drc::Drc,
    /// The view-only ruler and whether its tool is armed.
    pub(super) measure: crate::board_measure::Measure,
    pub(super) draft: Option<crate::board_canvas::Draft>,
    pub(super) reference_drag: Option<crate::board_canvas::ReferenceDrag>,
    pub(super) reference: crate::board_reference::State,
    pub(super) placement: Option<crate::board_canvas::Placement>,
    pub(super) box_drag: Option<crate::board_canvas::BoxDrag>,
    /// Only an idle secondary press may open a context menu on release; tool cancellation cannot.
    pub(super) context_menu_allowed: bool,
    pub(super) move_requested: bool,
    /// Counterclockwise degrees on screen; the board camera converts this intent to model space.
    pub(super) rotate_requested: u16,
    /// F: flip the hovered or selected footprint, or the footprint being moved, to the other side.
    pub(super) flip_requested: bool,
    /// `: highlight the net under the pointer, or clear the highlight over empty space.
    pub(super) net_highlight_requested: bool,
    /// The net whose pads and copper are drawn highlighted in this view.
    pub(super) highlight_net: Option<String>,
    /// Reuse derived copper connectivity while the addressed board and revision stay unchanged.
    pub(super) copper_connectivity_cache: Option<CopperConnectivityCache>,
    pub(super) selection: std::collections::BTreeSet<String>,
    pub(super) hidden_layers: std::collections::BTreeSet<String>,
    pub(super) layer_defaults_applied: bool,
    pub(super) active_layer: Option<String>,
    pub(super) layers_collapsed: bool,
    pub(super) browser_collapsed: bool,
    pub(super) properties_collapsed: bool,
    pub(super) target: Option<BoardTarget>,
}

impl BoardState {
    /// Footprints used only for correspondence include a selected reference's owning placement.
    pub(super) fn probe_footprints(&self) -> std::collections::BTreeSet<String> {
        self.selection.iter().cloned().chain(self.reference.selected.iter().cloned()).collect()
    }
    /// Whether a footprint or its reference currently owns a placement gesture.
    pub(super) fn editing_footprint(&self) -> bool {
        self.draft.is_some() || self.reference_drag.is_some()
    }

    /// Reuse connectivity for the same board and view/revision authority. Missing authority
    /// recomputes without caching, so disposable previews cannot borrow another opening's data.
    pub(super) fn copper_connectivity(
        &mut self,
        board: pcbcraft_engine::board::view::BoardView<'_>,
        source: Option<ViewInput>,
    ) -> Arc<crate::board_appearance::Connectivity> {
        if let Some(cache) = &self.copper_connectivity_cache
            && Some(cache.source) == source
            && cache.target == board.target
        {
            return cache.connectivity.clone();
        }
        let (copper, nets) = board.copper_with_nets();
        let connectivity = Arc::new(crate::board_appearance::Connectivity { copper, nets });
        self.copper_connectivity_cache =
            source.map(|source| CopperConnectivityCache { source, target: board.target, connectivity: connectivity.clone() });
        connectivity
    }

    /// Share revision-keyed accepted geometry between frames; navigation never invalidates it.
    /// Missing input authority is recomputed rather than reusing a possibly foreign opening.
    pub(super) fn ratsnest(
        &mut self,
        board: pcbcraft_engine::board::view::BoardView<'_>,
        source: Option<ViewInput>,
    ) -> Option<std::sync::Arc<pcbcraft_engine::board::ratsnest::Ratsnest>> {
        if let Some((previous, cached)) = &self.ratsnest_cache
            && Some(*previous) == source
            && cached.board == board.target
        {
            return Some(cached.clone());
        }
        let result = board.ratsnest().map(std::sync::Arc::new);
        self.ratsnest_cache = source.zip(result.clone());
        result
    }

    /// Change only this view's accepted-connection overlay, using its saved presentation set.
    pub(super) fn set_ratsnest_visibility(&mut self, visible: bool) {
        if visible {
            self.hidden_layers.remove(RATSNEST_KEY);
        } else {
            self.hidden_layers.insert(RATSNEST_KEY.into());
        }
    }

    /// Replace the view's layer visibility in one action; isolation always reveals the active layer.
    /// Ratsnest visibility is independent of physical layer actions. Neither document revision
    /// nor saved files change, and unfinished drawing gestures expire.
    pub(super) fn set_layer_visibility(&mut self, layers: impl IntoIterator<Item = String>, active_only: bool) {
        self.drawing.cancel();
        self.tracks.cancel();
        let ratsnest_hidden = self.hidden_layers.contains(RATSNEST_KEY);
        self.hidden_layers = layers.into_iter().filter(|id| active_only && self.active_layer.as_ref() != Some(id)).collect();
        if ratsnest_hidden {
            self.hidden_layers.insert(RATSNEST_KEY.into());
        }
    }

    /// Apply view-local layer choices through the same handler for Layers and live control.
    /// Changing the active layer or hiding it cancels disposable drawing gestures.
    pub(super) fn set_layer(&mut self, id: &str, active: bool, visible: Option<bool>) {
        if active && self.active_layer.as_deref() != Some(id) {
            self.drawing.cancel();
            self.active_layer = Some(id.to_owned());
        }
        if let Some(visible) = visible {
            if visible {
                self.hidden_layers.remove(id);
            } else {
                self.drawing.cancel();
                self.tracks.cancel();
                self.hidden_layers.insert(id.to_owned());
            }
        }
    }
}

/// One view retains independent navigation and selection for each built-in workspace.
/// Neither its current target nor switching workspaces changes history or saved bytes.
#[derive(Debug)]
pub(super) struct EditorView {
    id: ViewId,
    binding: Option<Binding>,
    input_epoch: u64,
    pub(super) workspace: Workspace,
    pub(super) filters: crate::selection_filters::Filters,
    pub(super) filters_collapsed: bool,
    pub(super) filters_open: bool,
    pub(super) panels: [pcbcraft_chrome::workspace::panels::Panel; 3],
    /// Runtime definition document, independent of the parked project workspace/target.
    pub(super) definition: Option<u64>,
    pub(super) camera: Camera,
    parked_camera: Camera,
    pub(super) schematic: SchematicState,
    pub(super) board: BoardState,
    unavailable: Option<ViewState>,
    /// Explicit sheet address survives workspace switches; immutable projections are cached per revision.
    sheet: Option<SheetTarget>,
    snapshot_root: Option<std::sync::Arc<pcbcraft_engine::Project>>,
    sheet_snapshot: Option<std::sync::Arc<pcbcraft_engine::Project>>,
}

impl Default for EditorView {
    fn default() -> Self {
        Self::new(ViewId::default())
    }
}

impl EditorView {
    /// Return a project target only; definition panes and unavailable placeholders grant no project authority.
    pub(super) fn target(&self) -> Option<DocumentTarget> {
        if self.definition.is_some() { None } else { self.binding.map(|binding| binding.target) }
    }

    /// Start a successfully opened project's default document in this workspace. Runtime identity,
    /// snap spacing and selection-filter choices survive, while old document addresses, navigation and edit authority expire.
    /// Saved arrangements are restored separately afterward and still validate explicit targets.
    /// Definition panes retain their document while refreshing the parked project presentation.
    pub(super) fn bind_opened_project(&mut self, session: &Session) {
        let definition = self.definition.take();
        let workspace = self.workspace;
        let snap_nm = self.camera.snap_nm();
        let filters = (self.filters, self.filters_collapsed, self.filters_open);
        let panels = self.panels.clone();
        *self = Self::new(self.id);
        (self.filters, self.filters_collapsed, self.filters_open) = filters;
        self.panels = panels;
        self.workspace = workspace;
        self.camera.set_snap_nm(snap_nm);
        self.sync(session);
        self.definition = definition;
    }

    /// Explicitly retarget a view after the host validates the document's existence.
    pub(super) fn open_document(&mut self, target: DocumentTarget, session: &Session) {
        match target {
            DocumentTarget::Sheet(sheet) => {
                self.switch(Workspace::Schematic, session);
                self.sheet = Some(sheet);
                self.sync(session);
            }
            DocumentTarget::Board(board) => {
                self.switch(Workspace::Board, session);
                self.board.target = Some(board);
                self.sync(session);
            }
            DocumentTarget::BoardWorkspace(_) => {
                self.switch(Workspace::Board, session);
                self.board.target = session.project().and_then(|project| project.board_target());
                self.sync(session);
            }
        }
    }

    /// Read a project view's sheet from the current authoritative revision; definition panes return None.
    /// A cached immutable
    /// projection avoids rebuilding geometry caches on every frame; stale caches never authorize input.
    pub(super) fn snapshot(&self, session: &Session) -> Option<std::sync::Arc<pcbcraft_engine::Project>> {
        if self.definition.is_some() {
            return None;
        }
        let root = session.snapshot()?;
        let target = self.sheet.unwrap_or_else(|| root.sheet_target());
        if self.snapshot_root.as_ref().is_some_and(|old| std::sync::Arc::ptr_eq(old, &root))
            && self.sheet_snapshot.as_ref().is_some_and(|p| p.sheet_target() == target)
        {
            return self.sheet_snapshot.clone();
        }
        root.for_sheet(target).map(std::sync::Arc::new).or_else(|| (self.workspace == Workspace::Board).then_some(root))
    }

    /// Capture project presentation only; runtime definition views are excluded from project
    /// arrangements. Unresolved saved targets remain intact instead of being rebound.
    pub(super) fn saved_state(&self, session: &Session) -> Option<ViewState> {
        if self.definition.is_some() {
            return None;
        }
        if let Some(state) = &self.unavailable {
            return Some(state.clone());
        }
        Some(self.presentation_state(self.binding?.target, self.sheet_path(session)?))
    }

    /// Capture navigation without resolving a target, including an explicit board that just
    /// became unavailable. Selection, gestures and input authority never enter the record.
    fn presentation_state(&self, target: DocumentTarget, title: String) -> ViewState {
        ViewState {
            target,
            title,
            camera: self.camera.saved_state(),
            parked_camera: self.parked_camera.saved_state(),
            board: self.board.target,
            schematic: self.sheet,
            hidden_layers: self.board.hidden_layers.clone(),
            active_layer: self.board.active_layer.clone(),
            layers_collapsed: self.board.layers_collapsed,
            browser_collapsed: self.board.browser_collapsed,
            properties_collapsed: self.board.properties_collapsed,
            filters: self.filters,
            filters_collapsed: self.filters_collapsed,
            filters_open: self.filters_open,
            panels: crate::workspace_panels::SavedPanels::capture(&self.panels),
        }
    }

    /// Resolve a saved target with a fresh runtime identity and no selection or gesture.
    /// Empty workspaces may bind the board subsequently created in their project. Missing
    /// explicit targets retain their snapshot and cannot authorize editing another document.
    /// Filter and card choices restore independently of selection, which always starts empty.
    pub(super) fn from_state(id: ViewId, state: &ViewState, session: &Session) -> Self {
        let mut view = Self::new(id);
        view.workspace = state.target.workspace();
        view.board.target = state.board;
        view.sheet = state.schematic;
        if let DocumentTarget::Sheet(sheet) = state.target {
            view.sheet = Some(sheet);
        }
        view.sync(session);
        let generic_board = matches!(state.target, DocumentTarget::BoardWorkspace(project) if session.project().is_some_and(|p| p.id() == project));
        if !generic_board && view.binding.is_none_or(|binding| binding.target != state.target) {
            view.binding = None;
            view.unavailable = Some(state.clone());
        }
        view.camera = Camera::from_state(&state.camera);
        view.parked_camera = Camera::from_state(&state.parked_camera);
        view.board.hidden_layers = state.hidden_layers.clone();
        view.board.layer_defaults_applied = true;
        view.board.active_layer = state.active_layer.clone();
        view.board.layers_collapsed = state.layers_collapsed;
        view.board.browser_collapsed = state.browser_collapsed;
        view.board.properties_collapsed = state.properties_collapsed;
        view.filters = state.filters;
        view.filters_collapsed = state.filters_collapsed;
        view.filters_open = state.filters_open;
        view.panels = state.panels.restore();
        view
    }

    /// Unavailable saved documents occupy a closeable view but never become an editing target.
    pub(super) fn unavailable(&self) -> bool {
        self.unavailable.is_some()
    }

    /// Create an unbound schematic presentation with fresh navigation and interaction state.
    pub(super) fn new(id: ViewId) -> Self {
        Self {
            id,
            binding: None,
            input_epoch: 0,
            workspace: Workspace::Schematic,
            filters: crate::selection_filters::Filters::default(),
            filters_collapsed: false,
            filters_open: true,
            panels: crate::workspace_panels::defaults(),
            definition: None,
            camera: Camera::default(),
            parked_camera: Camera::default(),
            schematic: SchematicState::default(),
            board: BoardState::default(),
            unavailable: None,
            sheet: None,
            snapshot_root: None,
            sheet_snapshot: None,
        }
    }

    /// Duplicate the displayed target/navigation and layer visibility, without copying selection
    /// or unfinished gestures. The two workspace cameras remain independent.
    pub(super) fn fork(&mut self, id: ViewId) -> Self {
        Self {
            binding: self.binding,
            sheet: self.sheet,
            snapshot_root: self.snapshot_root.clone(),
            sheet_snapshot: self.sheet_snapshot.clone(),
            workspace: self.workspace,
            filters: self.filters,
            filters_collapsed: self.filters_collapsed,
            filters_open: self.filters_open,
            panels: self.panels.clone(),
            definition: self.definition,
            camera: self.camera.fork_navigation(),
            parked_camera: self.parked_camera.fork_navigation(),
            unavailable: self.unavailable.clone(),
            board: BoardState {
                target: self.board.target,
                layers_collapsed: self.board.layers_collapsed,
                browser_collapsed: self.board.browser_collapsed,
                properties_collapsed: self.board.properties_collapsed,
                hidden_layers: self.board.hidden_layers.clone(),
                layer_defaults_applied: self.board.layer_defaults_applied,
                active_layer: self.board.active_layer.clone(),
                ..BoardState::default()
            },
            ..Self::new(id)
        }
    }

    /// Seed a host replacement without consuming this view's deferred navigation. The new
    /// view receives the displayed transforms, while both original cameras keep pending requests.
    pub(super) fn fork_replacement(&mut self, id: ViewId) -> Self {
        let camera = self.camera.clone();
        let parked_camera = self.parked_camera.clone();
        let replacement = self.fork(id);
        self.camera = camera;
        self.parked_camera = parked_camera;
        replacement
    }

    /// Switch only this view and restore that workspace's navigation. Old input remains invalid
    /// even when switching back without any document edit.
    pub(super) fn switch(&mut self, workspace: Workspace, session: &Session) {
        if self.definition.take().is_some() {
            self.release_input();
        }
        if self.unavailable.is_some() {
            let filters = (self.filters, self.filters_collapsed, self.filters_open);
            let panels = self.panels.clone();
            *self = Self::new(self.id);
            (self.filters, self.filters_collapsed, self.filters_open) = filters;
            self.panels = panels;
            self.sync(session);
        }
        if self.workspace == workspace || session.project().is_none() {
            return;
        }
        self.release_input();
        std::mem::swap(&mut self.camera, &mut self.parked_camera);
        self.workspace = workspace;
        self.binding = Binding::current(session, workspace, self.board.target, self.sheet);
    }

    /// Identify the input owner independently of the currently focused host.
    pub(super) fn id(&self) -> ViewId {
        self.id
    }

    /// Resolve the document breadcrumb; a runtime view number is never a sheet name.
    pub(super) fn sheet_path(&self, session: &Session) -> Option<String> {
        if let Some(state) = &self.unavailable {
            return Some(format!("{} (unavailable)", state.title));
        }
        self.input(session)?;
        let name = match self.workspace {
            Workspace::Schematic => self.sheet_snapshot.as_ref()?.sheet_name(),
            Workspace::Board => match self.board.target {
                Some(target) => session.project()?.board_view(target)?.name(),
                None => Workspace::Board.title(),
            },
        };
        Some(format!("{} › {name}", session.project()?.name))
    }

    /// Both targets must resolve in this session's current opening to exchange correspondence.
    pub(super) fn shares_project(&self, other: &Self, session: &Session) -> bool {
        self.input(session).is_some() && other.input(session).is_some()
    }

    /// Two schematic views of the same sheet share literal schematic selection addresses.
    pub(super) fn shares_sheet(&self, other: &Self, session: &Session) -> bool {
        self.workspace == Workspace::Schematic && self.binding == other.binding && self.shares_project(other, session)
    }

    /// Scope widgets to their document; captured actions separately validate the input epoch.
    pub(super) fn widget_id(&self) -> egui::Id {
        egui::Id::unique((self.id, self.binding))
    }

    /// Capture input only while this view is bound to its current document opening.
    pub(super) fn input(&self, session: &Session) -> Option<ViewInput> {
        if self.definition.is_some() {
            return None;
        }
        let binding = self.binding.filter(|binding| Some(*binding) == Binding::current(session, self.workspace, self.board.target, self.sheet))?;
        Some(ViewInput { view: self.id, target: Some(binding.target), definition: None, input_epoch: self.input_epoch, revision: session.revision() })
    }

    /// Permit layout controls for definition and unavailable views without granting project edit
    /// authority. Definition tokens include runtime document identity and the view's input epoch.
    pub(super) fn control_input(&self, session: &Session) -> Option<ViewInput> {
        if let Some(document) = self.definition {
            return Some(ViewInput { view: self.id, target: None, definition: Some(document), input_epoch: self.input_epoch, revision: 0 });
        }
        self.input(session).or_else(|| {
            self.unavailable.as_ref().map(|state| ViewInput {
                view: self.id,
                target: Some(state.target),
                definition: None,
                input_epoch: self.input_epoch,
                revision: session.revision(),
            })
        })
    }

    /// Refuse another view's, old workspace's or stale revision's action.
    pub(super) fn accepts(&self, input: ViewInput, session: &Session) -> bool {
        self.input(session) == Some(input)
    }

    /// Drop unfinished gestures without altering selection or the document.
    pub(super) fn cancel_gesture(&mut self) {
        self.board.drc.cancel();
        self.schematic.clipboard = crate::clipboard::State::default();
        self.board.clipboard = crate::board_clipboard::State::default();
        self.board.drawing.cancel();
        self.board.tracks.cancel();
        self.board.measure.cancel();
        self.board.draft = None;
        self.board.reference_drag = None;
        self.board.placement = None;
        self.board.box_drag = None;
        self.board.move_requested = false;
        self.board.rotate_requested = 0;
        self.board.flip_requested = false;
        self.schematic.tool = None;
        self.schematic.wire_draft = Draft::default();
        self.schematic.rotate_requested = false;
        self.schematic.mirror_requested = None;
        self.schematic.edit_requested = false;
        self.schematic.text_edit = None;
        self.schematic.datasheet_requested = false;
        self.schematic.move_requested = false;
    }

    /// Invalidate captured input and stop wheel animation on focus or host transitions,
    /// retaining the displayed transforms of both cameras.
    pub(super) fn release_input(&mut self) {
        self.cancel_gesture();
        self.camera.cancel_zoom();
        self.parked_camera.cancel_zoom();
        for panel in &mut self.panels {
            panel.cancel_drag();
        }
        self.input_epoch += 1;
    }

    /// Reopening resets local state while retaining workspace choice, grid and filters. Ordinary edits
    /// prune removed selections/layers. A stale segment clears its whole selection so Delete
    /// cannot widen into a wire deletion; synchronization never mutates the session. Explicit
    /// sheet/board targets that no longer resolve become unavailable, closeable placeholders;
    /// undo restores their address and navigation. Only omitted targets use compatibility defaults.
    pub(super) fn sync(&mut self, session: &Session) -> bool {
        if self.definition.is_some() {
            return false;
        }
        if let Some(state) = &self.unavailable {
            if state.target.available(session) {
                *self = Self::from_state(self.id, &state.clone(), session);
                return true;
            }
            return false;
        }
        let root = session.snapshot();
        if self.snapshot_root.as_ref().zip(root.as_ref()).is_some_and(|(old, new)| !old.same_document(new)) {
            self.sheet = None;
        }
        if self.sheet.is_none() {
            self.sheet = root.as_ref().map(|p| p.sheet_target());
        }
        if self.workspace == Workspace::Schematic
            && self.sheet.is_some()
            && root.as_ref().is_some_and(|p| self.sheet.and_then(|target| p.for_sheet(target)).is_none())
        {
            let target = self.sheet.map(DocumentTarget::Sheet);
            if let Some(target) = target {
                let title = self.sheet_snapshot.as_ref().map_or("Sheet", |p| p.sheet_name()).to_owned();
                self.unavailable = Some(self.presentation_state(target, title));
                self.binding = None;
                self.release_input();
                self.schematic.selection = Selection::default();
                self.sheet_snapshot = None;
            }
            return true;
        }
        let board_target = self.board.target.or_else(|| session.project().and_then(|p| p.board_target()));
        if self.workspace == Workspace::Board
            && let Some(target) = board_target
            && session.project().is_some_and(|project| project.board_view(target).is_none())
        {
            self.unavailable = Some(self.presentation_state(DocumentTarget::Board(target), Workspace::Board.title().into()));
            self.release_input();
            self.binding = None;
            self.schematic = SchematicState::default();
            self.board.selection.clear();
            self.board.reference = Default::default();
            return true;
        }
        let binding = Binding::current(session, self.workspace, board_target, self.sheet);
        let changed = self.binding != binding;
        if changed {
            let snap_nm = self.camera.snap_nm();
            let workspace = self.workspace;
            let sheet = self.sheet;
            let filters = (self.filters, self.filters_collapsed, self.filters_open);
            let panels = self.panels.clone();
            *self = Self::new(self.id);
            (self.filters, self.filters_collapsed, self.filters_open) = filters;
            self.panels = panels;
            self.sheet = sheet;
            self.workspace = workspace;
            self.camera.set_snap_nm(snap_nm);
            self.binding = binding;
        }
        self.board.target = board_target;
        // A highlighted net that no pad carries any more (after an edit, undo or rename) clears,
        // so the status bar never names a net that nothing on the board shows.
        if let Some(net) = &self.board.highlight_net
            && !root
                .as_ref()
                .and_then(|p| board_target.and_then(|target| p.board_view(target)))
                .is_some_and(|board| board.footprints().any(|footprint| footprint.pads.iter().any(|pad| pad.net.as_deref() == Some(net.as_str()))))
        {
            self.board.highlight_net = None;
        }
        if !self.snapshot_root.as_ref().zip(root.as_ref()).is_some_and(|(old, new)| std::sync::Arc::ptr_eq(old, new))
            || self.sheet_snapshot.as_ref().map(|p| p.sheet_target()) != self.sheet
        {
            self.sheet_snapshot = root.as_ref().and_then(|p| {
                let target = self.sheet?;
                if p.sheet_target() == target { Some(p.clone()) } else { p.for_sheet(target).map(std::sync::Arc::new) }
            });
            self.snapshot_root = root;
        }
        if self.board.box_drag.as_ref().is_some_and(|drag| !self.accepts(drag.source, session)) {
            self.cancel_gesture();
        }
        if self.board.placement.as_ref().is_some_and(|placement| !self.accepts(placement.source, session)) {
            self.board.placement = None;
        }
        if self.board.draft.as_ref().is_some_and(|draft| !self.accepts(draft.source, session)) {
            self.cancel_gesture();
        }
        if self.board.reference_drag.as_ref().is_some_and(|draft| !self.accepts(draft.source, session)) {
            self.board.reference_drag = None;
        }
        if self.board.drawing.source().is_some_and(|source| !self.accepts(source, session)) {
            self.cancel_gesture();
        }
        if self.schematic.tool.as_ref().is_some_and(|tool| tool.revision() != session.revision()) {
            self.cancel_gesture();
        }
        if self.schematic.selected_leg.as_ref().is_some_and(|leg| leg.revision != session.revision()) {
            self.schematic.selected_leg = None;
            self.schematic.selection = Selection::default();
        }
        if !matches!(self.schematic.tool, Some(Tool::Wire { .. })) {
            self.schematic.wire_draft = Draft::default();
        }
        if let Some(project) = session.project() {
            if let Some(sheet) = &self.sheet_snapshot {
                self.schematic.selection.retain(sheet);
                self.schematic.selected_sheet_symbol =
                    self.schematic.selected_sheet_symbol.filter(|id| sheet.sheet_symbols().iter().any(|s| s.id == *id));
            } else {
                self.schematic.selection = Selection::default();
                self.schematic.selected_sheet_symbol = None;
            }
            let placed: std::collections::BTreeSet<_> = self
                .board
                .target
                .and_then(|target| project.board_view(target))
                .into_iter()
                .flat_map(|board| board.footprints())
                .map(|footprint| footprint.id)
                .collect();
            self.board.selection.retain(|id| placed.contains(id));
            if self.board.reference.selected.as_ref().is_some_and(|id| !placed.contains(id)) {
                self.board.reference = Default::default();
            }
            let setup = self.board.target.and_then(|target| project.board_view(target)).and_then(|board| board.setup());
            let layers: std::collections::BTreeSet<_> = self
                .board
                .target
                .and_then(|target| project.board_view(target))
                .into_iter()
                .flat_map(|board| board.layers())
                .map(|layer| layer.id.to_string())
                .collect();
            if !self.board.layer_defaults_applied
                && let Some(setup) = setup
            {
                use pcbcraft_engine::board::setup::LayerPurpose;
                self.board.hidden_layers.extend(
                    setup
                        .layers()
                        .iter()
                        .filter(|layer| matches!(layer.purpose, LayerPurpose::Fabrication | LayerPurpose::Courtyard))
                        .map(|layer| layer.id.to_string()),
                );
                self.board.layer_defaults_applied = true;
            }
            self.board.hidden_layers.retain(|id| id == RATSNEST_KEY || layers.contains(id));
            if self.board.active_layer.as_ref().is_none_or(|id| !layers.contains(id)) {
                self.board.active_layer = setup
                    .and_then(|setup| {
                        setup.stackup().strata.iter().find_map(|stratum| {
                            if let pcbcraft_engine::board::setup::Stratum::Copper { layer, .. } = stratum { Some(layer.to_string()) } else { None }
                        })
                    })
                    .or_else(|| {
                        self.board
                            .target
                            .and_then(|target| project.board_view(target))
                            .and_then(|board| {
                                board.layers().into_iter().find(|layer| layer.purpose == pcbcraft_engine::board::setup::LayerPurpose::Outline)
                            })
                            .map(|layer| layer.id.to_string())
                    });
            }
        }
        changed
    }
}
