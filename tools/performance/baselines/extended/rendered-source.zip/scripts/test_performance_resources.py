"""Resource evidence must come from actual profiler output, not absent-data zeros."""
import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location("resources", Path(__file__).with_name("collect-performance-resources.py"))
resources = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resources)


class ResourcesTests(unittest.TestCase):
    def test_allocation_totals_parse_thousands_and_reject_missing_evidence(self):
        self.assertEqual(resources.allocation_totals("==42== total heap usage: 1,024 allocs, 999 frees, 123,456 bytes allocated"),
                         dict(allocations=1024, frees=999, bytes_allocated=123456))
        with self.assertRaises(ValueError):
            resources.allocation_totals("profiling stopped before statistics")

    def test_missing_process_is_unavailable(self):
        self.assertEqual(resources.resident_memory(999999999), {})


if __name__ == "__main__":
    unittest.main()
