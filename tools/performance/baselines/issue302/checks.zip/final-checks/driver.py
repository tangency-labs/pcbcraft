from pathlib import Path
import subprocess,os,json,time
root=Path('/home/travisl/projects/PCBcraft/setup/issue302')
logs=root/'checks';logs.mkdir(exist_ok=True)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/travisl/projects/PCBcraft/main/target';env['CARGO_TARGET_WASM32_WASIP1_RUNNER']='node --no-warnings /home/travisl/projects/PCBcraft/work/net-class-consumers/scripts/wasi-test-runner.cjs'
checks=[
 ('remaining-workspace-tests',['cargo','test','--locked','-p','pcbcraft-engine','-p','pcbcraft-mcp','-p','pcbcraft-storage','-p','pcbcraft-units','-p','pcbcraft-cli','-p','pcbcraft-web']),
 ('fmt',['cargo','fmt','--all','--check']),
 ('clippy',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','warnings']),
 ('harness-clippy',['cargo','clippy','--locked','-p','pcbcraft-app','--features','performance-harness','--all-targets','--','-D','warnings']),
 ('harness-tests',['cargo','test','--locked','-p','pcbcraft-app','--features','performance-harness','performance::']),
 ('python-performance',['python3','-B','-m','unittest','discover','-s','scripts','-p','test*performance*.py']),
 ('node-performance',['node','--no-warnings','--experimental-vm-modules','--test','scripts/test-performance-page.cjs','scripts/test-rendered-performance-page.cjs']),
 ('wasi-runner',['node','--test','scripts/test-wasi-test-runner.cjs']),
 ('wasi-board',['cargo','test','--locked','-p','pcbcraft-engine','--target','wasm32-wasip1','--lib','board::','--','--test-threads=1']),
 ('wasi-net-classes',['cargo','test','--locked','-p','pcbcraft-engine','--target','wasm32-wasip1','--lib','net_classes::','--','--test-threads=1']),
 ('wasi-nets',['cargo','test','--locked','-p','pcbcraft-engine','--target','wasm32-wasip1','--lib','nets::','--','--test-threads=1']),
 ('web-check',['cargo','check','--locked','-p','pcbcraft-web','--target','wasm32-unknown-unknown']),
 ('web-harness',['cargo','check','--locked','-p','pcbcraft-app','--features','performance-harness','--example','board_perf_web','--target','wasm32-unknown-unknown']),
 ('native-build',['cargo','build','--locked','-p','pcbcraft','-p','pcbcraft-cli']),
 ('dependencies',['cargo','deny','--locked','check','licenses','sources','bans']),
 ('release-harness-build',['cargo','build','--locked','--release','-p','pcbcraft-app','--features','performance-harness','--example','board_perf']),
]
results=[]
for name,cmd in checks:
 print('Running '+name,flush=True);started=time.monotonic()
 with (logs/(name+'.log')).open('wb') as f:
  run=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 results.append({'name':name,'command':cmd,'exit_code':run.returncode,'elapsed_s':round(time.monotonic()-started,3)})
 (logs/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name+': '+str(run.returncode),flush=True)
 if run.returncode:break
