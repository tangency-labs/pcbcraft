from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/home/travisl/projects/PCBcraft/setup/issue302/review349');root.mkdir(exist_ok=True)
paths=[Path('crates/engine/src/board/class_rules.rs'),Path('crates/app/src/board_tracks.rs'),Path('crates/app/src/performance.rs')]
saved={p:p.read_bytes() for p in paths}
try:
 s=saved[paths[0]].decode().replace('None => operand(PreferredViaDiameterNm, explicit_drill)?,','None => self.value(PreferredViaDiameterNm)?,').replace('None => operand(PreferredViaDrillNm, explicit_diameter)?,','None => self.value(PreferredViaDrillNm)?,')
 paths[0].write_text(s)
 s=saved[paths[1]].decode().replace('policy.track_width(self.width_override)?','policy.track_width(None)?').replace('policy.via_sizes(self.via_diameter_override, self.via_drill_override)','policy.via_sizes(None, None)')
 s=s.replace('self.width_override.unwrap_or(base.preferred_track_width_nm)','base.preferred_track_width_nm').replace('self.via_diameter_override.unwrap_or(base.preferred_via_diameter_nm)','base.preferred_via_diameter_nm').replace('self.via_drill_override.unwrap_or(base.preferred_via_drill_nm)','base.preferred_via_drill_nm')
 paths[1].write_text(s)
 s=saved[paths[2]].decode();start=s.index('    let mut added = tracks.iter().filter(|track| !before.contains(&track.id));');end=s.index('\n    Ok(())\n}',start)
 s=s[:start]+'''    let _ = (before,end,layer);
    if !tracks.iter().any(|track| track.start==start && track.width_nm==width) {
        return Err("missing expected width".into());
    }'''+s[end:];paths[2].write_text(s)
 env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/travisl/projects/PCBcraft/main/target'
 results=[]
 for name,cmd in [
 ('via',['cargo','test','--locked','-p','pcbcraft-engine','--lib','explicit_via_operand_repairs']),
 ('sizes',['cargo','test','--locked','-p','pcbcraft-app','--lib','explicit_sizes_survive']),
 ('oracle',['cargo','test','--locked','-p','pcbcraft-app','--features','performance-harness','--lib','route_oracle_requires'])]:
  print('Counterfactual '+name,flush=True)
  with (root/('counterfactual-'+name+'.log')).open('wb') as f:result=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  text=(root/('counterfactual-'+name+'.log')).read_text()
  valid=result.returncode==101 and 'test result: FAILED.' in text
  results.append({'name':name,'exit_code':result.returncode,'expected_test_failure':valid})
  (root/'counterfactual.json').write_text(json.dumps(results,indent=2)+'\n');print(name+': '+str(valid),flush=True)
  if not valid:break
finally:
 for p,content in saved.items():p.write_bytes(content)
 print('Corrected sources restored.',flush=True)
